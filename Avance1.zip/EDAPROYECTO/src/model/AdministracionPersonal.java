/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author KEVIN
 */
public class AdministracionPersonal {
    
    private Personal P;
            
   public AdministracionPersonal()
   {
       this.P = null;
   }
   
   public boolean estaVacia()
   {
       if (this.P == null)
            return true;
       return false;
   }
   
   /*public void mostrar()
   {
       Interesado ptr = this.I;
       while (ptr !=null)
       {
           System.out.print( ptr.getID() + "\n"+
                            ptr.);
           ptr = ptr.getNext();
       }
       System.out.println("");
   }
   */
   public void insertar(String ID, String contraseña, String nombre, String correo)
   {
       Personal nuevo = new Personal(ID, contraseña, nombre, correo);
       if(estaVacia())
       {
           this.P = nuevo;
       }
       else
       {
           Personal ptr = this.P;
           while (ptr.getSgte() != null)
           {
               ptr = ptr.getSgte();
           }
           ptr.setSgte(nuevo);
           
       }
       
   }
   
   public String buscar(String ID)
   {
       Personal ptr = this.P;
       while (ptr != null && ptr.getID() != ID)
       {
           ptr = ptr.getSgte();
       }
       if (ptr == null)
       {
           return "-1";
       }
       else
       {
           return ptr.getID();
       }
   }
   
   public void eliminar(String ID)
   {
       Personal ptr = this.P;
       Personal prev = null;
       while (ptr != null && ptr.getID() != ID)
       {
           prev = ptr;
           ptr = ptr.getSgte();  
       }
       if (ptr != null && ptr.getID() != ID)
       {
           if (prev == null) //eliminando al primero de la lista
           {
               this.P = ptr.getSgte();
           }
           else
           {   
            prev.setSgte(ptr.getSgte());
           }
       }
   }
}
