/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author KEVIN
 */
public class demo {
    public static void main(String[] args) {
        AdministracionInteresados AI = new AdministracionInteresados();
        
        AI.insertar("ID", "contraseña", "nombre", "correo");
        AI.buscar("ID");
    }
}
