/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author KEVIN
 */
public abstract class Usuario {
    
    protected String ID, contraseña, nombre, correo;
    private String tipo;
    

    public Usuario() {
        this.ID="";
        this.contraseña="";
        this.correo="";
        this.nombre="";
    }

    
    
    public Usuario(String ID, String contraseña, String nombre, String correo) {
        this.ID = ID;
        this.contraseña = contraseña;
        this.nombre = nombre;
        this.correo = correo;
    }

    


    
    
}
